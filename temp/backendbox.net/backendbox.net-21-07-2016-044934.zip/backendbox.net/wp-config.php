<?php
/** Enable W3 Total Cache */
define('WP_CACHE', true); // Added by W3 Total Cache



// ** MySQL settings ** //
/** The name of the database for WordPress */
define('DB_NAME', 'backendbox_net');

/** MySQL database username */
define('DB_USER', 'backendbox_net');

/** MySQL database password */
define('DB_PASSWORD', 'MFV42KZ7HCkv6cm');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

define('AUTH_KEY',         'M{|Bg%jVHrP`l<E_l|LUbi/[N_]Z@)K8D2;r%8L_@]<4ywWZm(A)BIc4d-qn ,B ');
define('SECURE_AUTH_KEY',  'gL*dLr7{}JI7 Ot .)@2kT|iywaRTxkIC|*3C#J-g3J97&Kn:23Utc?.zx33_GN7');
define('LOGGED_IN_KEY',    'vu+P`)cs-Pp`>SA%@y/VeHUlabq5{u00vNcF-gy@xu2]tr;JhY[B1}o]+]47A9RC');
define('NONCE_KEY',        'EI(`zt,1=:B2-U3.)& *nn_ULvSI&fzcbSn.r^z-IQncz>ij,oth@smH*+sos>AA');
define('AUTH_SALT',        '.6[@+[DJD[eMo,{ZG19ihH+nei+@)2@rl~I_eGb9dMKzv]-J%n[^0y2C~fU|:HBR');
define('SECURE_AUTH_SALT', '[_ia|Qv SJ7@@=W&?IxIbX$]Y/2j!Wtugb:EaE_AuC.c=K9)d 2E-=ifJsU9&rp+');
define('LOGGED_IN_SALT',   '6d!hYZ}g_B4b[`omI[n<x|Gt<a]h#P{u/+*%iv=F{g>4R!is94)|JGD)s0BPL^w>');
define('NONCE_SALT',       'e}Lf<F_T%4+XaF;dS>HAT!q;B=Fs&!Aw +3Kjgx6Oe,Bc}|~#vY!r6dtzBLp0*U8');


$table_prefix = 'wp_';


 

define('WP_DEBUG', false); 



/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
